#ifndef HISTORIQUE_H
#define HISTORIQUE_H

#include "modec.h" 
#include "modegestion.h"

int enregistrer_historique(Produit fleur, Client client);
int afficher_historique(Client client);

#endif
