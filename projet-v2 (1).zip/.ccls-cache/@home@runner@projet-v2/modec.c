#include <stdio.h>
#include <stdlib.h>
#define MAX_CLIENTS 100


typedef struct Client{
char nom[20];
char prenom[20];
char historique1[20];

}Client;

/*void createaccount(){
  Client *a=malloc(sizeof(Client));
  printf("entrer votre nom:");
  scanf("%s",a->nom);
  printf("entrer votre prenom:");
  scanf("%s",a->prenom);
  
  }  
 void historique(FILE* historique==NULL){
  Client *b=malloc(sizeof (Client));
  printf("veuillez renseigner votre nom:");
  scanf("%s",b->nom);
  printf("veuillez renseigner votre prenom:");
  scanf("%s",b->prenom);
   if (historique != NULL)
    {
        fopen("historique", "r+");
        fprintf(historique, b->nom, "\n");
        fclose(historique);
    }
  }
  
*/



int main1() {

Client clients[MAX_CLIENTS];
int nb_clients = 0;
int choix;
int reponse;

printf("Êtes-vous déjà client ? Tapez 0 sinon tapez 1 : ");
scanf("%d", &reponse);

if (reponse == 0) {
printf("De retour !\n");
} else if (reponse == 1) {
printf("Voulez-vous créer un compte client ? Tapez 1 pour oui ou 2 pour non : ");
scanf("%d", &choix);

if (choix == 1) {
Client nouveau_client;

printf("Nom : ");
scanf("%s", nouveau_client.nom);

printf("Prénom : ");
scanf("%s", nouveau_client.prenom);

clients[nb_clients] = nouveau_client;
nb_clients++;

printf("Compte client créé avec succès.\n");
} else {
printf("Erreur, veuillez ressaisir.\n");
}
}

return 0;
}
