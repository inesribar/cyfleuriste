#include <stdio.h>
#include <stdlib.h>
#include "stock.h"
// module gestion stock :

// Ajouter un produit à la base de donnée
int stock(){
char nom_produit[50];
int quantite;
int reference;
char taille[20];
float prix;

printf("Entrez le nom du produit : \n ");
scanf("%s", nom_produit);

printf("Entrez le numéro de référencement : \n");
scanf("%d",&reference);
	
printf("Entrez la quantité disponible looool: ");
scanf("%d", &quantite);

printf("Entrez le prix du produit : ");
scanf("%f", &prix);

printf("Entrez petit moyen ou grand selon la taille du produit : ");
scanf("%s",taille);

printf("\nNom du produit : %s", nom_produit);
printf("\nQuantité disponible : %d", quantite);
printf("\nPrix du produit : %f", prix);
printf("\nRéférence du produit :%d",reference);
printf("\nTaille du produit %s",taille);
	return 0;
}