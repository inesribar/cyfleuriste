// Projet  de course CY-Shop
// Ines Ribar Kanto Andriambololo-Nivo Berlyse
#include <stdio.h>
#include <stdlib.h>

/*int main(void) {
  int choix;
  FILE *fichier=NULL;


  printf("Bienvenue chez CY Fleuriste !\n");
  printf(" Identifiez vous : \n");
  printf(" Client tapez 1 | Employé tapez 2 \n");

  scanf("%d", &choix);

  if (choix == 1) {
    fichier = fopen("modeclient.c", "r+");
		    fichier = fopen("modeclient.c", "r+");
		    		  

		
    if (fichier == NULL) { 
    printf("Erreur : impossible d'ouvrir le premier fichier\n");
      // printf("code d'erreur = %d \n", errno );
     // printf("Message d'erreur = %s \n", strerror(errno) );

      exit(1);
  }
       printf("Vous êtes dans le mode client\n");
       	system("gcc modeclient.c -o modeclient");
		system("./modeclient");
		
       fclose(fichier);
 } 
   else if (choix == 2) {
    fichier = fopen("modeemploye.c", "r");
    if (fichier == NULL) {
      printf("Erreur : impossible d'ouvrir le deuxième fichier\n");
      exit(1);
    }
    printf("Vous êtes dans le mode employé \n");
    fclose(fichier);
  } else {
   printf("Vous n'avez pas choisi de fichier à ouvrir\n");
  }



  return 0;
}
*/



int main(void) {
  int choix;

  printf("Bienvenue chez CY Fleuriste !\n");
  printf("Identifiez vous : \n");
  printf("Client tapez 1 | Employé tapez 2 \n");

  scanf("%d", &choix);

  if (choix == 1) {
    printf("Vous êtes dans le mode client\n");
   //system("gcc modec.c -o modec");
    system("./modec.c");
    // TODO: Inclure le code pour le mode client ici
  } else if (choix == 2) {
    printf("Vous êtes dans le mode employé\n");
    system("./modeemploye"); // Exécuter le programme "modeemploye"
  } else {
    printf("Vous n'avez pas choisi de mode valide\n");
  }

  return 0;
}
