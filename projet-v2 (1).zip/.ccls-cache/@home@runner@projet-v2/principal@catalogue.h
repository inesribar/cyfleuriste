define MAX_HISTORIQUE = 3

struct Historique {
    struct Fleur fleur[MAX_HISTORIQUE];
    int count;
};