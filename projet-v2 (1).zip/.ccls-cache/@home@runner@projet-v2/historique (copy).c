/*#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include"historique.h"
#include "modec.h"
#include "modegestion.h"


#define MAX_ACHAT 100*/

/*void enregistrer_historique(Produit fleur) {
    Client client ;
    // Ouvrir le fichier du client en mode "a" pour ajouter à la fin du fichier
    FILE *fichier_client = fopen("client.nom_client.prenom.txt", "a");
    if (fichier_client == NULL) {
        printf("Impossible d'ouvrir le fichier client.txt.\n");
        return;
    }

    // Écrire l'information d'achat dans le fichier du client
    fprintf(fichier_client, "Produit : %s\n", fleur.nom);
    fprintf(fichier_client, "Quantité : %d\n", fleur.quantite);
    fprintf(fichier_client, "Référence : %d\n", fleur.reference);
    fprintf(fichier_client, "Prix : %.2f\n", fleur.prix);

    // Fermer le fichier du client
    fclose(fichier_client);

    printf("achat enregistré\n\n");

}*/