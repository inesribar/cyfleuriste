#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stock.h"

#define MAX_PRODUCTS 100

void afficherProduitsStockZero(Produits produits[], int nbProduits) {
    printf("Produits avec stock à 0 :\n");
    for (int i = 0; i < nbProduits; i++) {
        if (produits[i].quantite == 0) {
            printf("- %s\n", produits[i].nom);
        }
    }
}

int main() {
    Produits produits[MAX_PRODUCTS];
    int nbProduits = 0;

    // Charger les produits depuis le fichier stock.txt
    FILE *fichier = fopen("stock.txt", "r");
    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return 1;
    }

    char ligne[100];
    while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
        char *nom = strtok(ligne, ",");
        int quantite = atoi(strtok(NULL, ","));
        float prix = atof(strtok(NULL, ","));

        strcpy(produits[nbProduits].nom, nom);
        produits[nbProduits].quantite = quantite;
        produits[nbProduits].prix = prix;

        nbProduits++;
    }

    fclose(fichier);

    afficherProduitsStockZero(produits, nbProduits);

    return 0;
}
