

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "modegestion.h"

int tri() {
    FILE *fichier = fopen("stock.txt", "r");
    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier de stock.\n");
        return 1;
    }

    char ligne[100];
    char nom[50];
    int quantite;
    int reference;
    float prix;

    printf("Produits avec stock à 0 :\n");
    while (fgets(ligne, sizeof(ligne), fichier)) {
        if (strncmp(ligne, "nom du produit: ", 16) == 0) {
            sscanf(ligne + 16, "%s", nom);

            fgets(ligne, sizeof(ligne), fichier);
            sscanf(ligne + 10, "%d", &quantite);

            fgets(ligne, sizeof(ligne), fichier);
            sscanf(ligne + 11, "%d", &reference);

            fgets(ligne, sizeof(ligne), fichier);
            sscanf(ligne + 17, "%f", &prix);

            if (quantite == 0) {
                printf("- %s\n", nom);
            }
        }
    }

    fclose(fichier);
    return 0;
}
