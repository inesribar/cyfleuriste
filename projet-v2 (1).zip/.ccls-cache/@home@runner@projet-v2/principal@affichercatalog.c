#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "modegestion.h"

int afficherCatalog() {
  Fleur catalog[]; 
  int catalogSize ;
    printf("Catalogue des fleurs :\n");
    for (int i = 0; i < catalogSize; i++) {
        printf("Nom : %s, Taille : %s, Quantite : %d, Reference : %s, Prix %s\n",
               catalog[i].nom, catalog[i].taille, catalog[i].quantité, catalog[i].reference), catalog[i].prix;
    }
}
